package com.lifesimplifier.life_simplifier_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifeSimplifierApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifeSimplifierApiApplication.class, args);
	}

}
