package com.lifesimplifier.life_simplifier_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifeSimplifierApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
